# Architecture

```
                    USER / FRAUD ANALYST
                            |
                            v
                 frontend/index.html
              (dashboard, investigate, chat, admin)
                            |
                            v
                  FastAPI (backend/app/main.py)
                            |
                            v
              Agent Orchestrator (backend/app/agent.py)
              explicit state machine, safety-railed
                            |
             +--------------+---------------+
             |              |               |
             v              v               v
    graph_engine.py     rag.py        policy_engine.py
    (TigerGraph-shaped   (GraphRAG:    (action policy
     query interface;    policies +    table, deterministic
     networkx in DEMO_    patterns      action selection)
     MODE, real GSQL      retrieval)
     via tigergraph/ when
     TIGERGRAPH_AVAILABLE)
             |              |               |
             v              v               v
       Graph Evidence   LLM Context     Permissions/Approval
             |              |               |
             +--------------+---------------+
                            v
                   risk_engine.py
             (deterministic, explainable
              weighted risk scoring)
                            v
                   case_manager.py
              (SQLite-backed case store +
               full audit log)
                            v
              Case memory / similar-case
              retrieval (graph_engine +
              closed_cases in the graph)
```

## Investigation flow (implemented exactly as specified)

```
TRIGGERED -> CASE_CREATED -> INVESTIGATING -> EVIDENCE_GATHERING ->
RISK_ASSESSMENT -> UNCERTAINTY_CHECK ->
  [MORE_EVIDENCE_REQUIRED -> REASSESSMENT]*  (bounded by MAX_EVIDENCE_ROUNDS)
-> ACTION_RECOMMENDATION -> HUMAN_APPROVAL (if required) -> ACTION_EXECUTION
-> CASE_RESOLUTION -> MEMORY_UPDATE
```

Implemented in `backend/app/agent.py::run_investigation`. Every transition is
appended to `case["timeline"]`, so the full state history is visible in the
UI's Investigation Timeline panel and via `GET /api/cases/{id}`.

## Why TigerGraph is abstracted behind `graph_engine.py`

There is no live TigerGraph cluster available in this build environment. To
keep the *real* deployment path honest rather than faked, the system is
split into:

1. **`tigergraph/schema/schema.gsql`** and **`tigergraph/gsql/queries.gsql`**
   — the actual GSQL you would install on a TigerGraph Savanna/Community
   instance. These are real, valid GSQL, not placeholders.
2. **`backend/app/graph_engine.py`** — a Python class exposing the exact same
   query methods (`get_connected_entities`, `find_similar_historical_cases`,
   etc.). In `DEMO_MODE` (default) it answers them from an in-memory
   `networkx` graph built from `data/sample/*.csv`, using the identical
   traversal logic the GSQL queries express. When `TIGERGRAPH_AVAILABLE=true`,
   swap the method bodies for `pyTigerGraph` calls to the installed queries
   — the agent, risk engine, and API layer do not change at all, because
   they only ever call `graph_engine.*`.

This means: (a) nothing about the agent's reasoning is faked to "look like"
graph analysis — it *is* graph traversal, just against an in-memory graph
instead of a hosted one, and (b) moving to a real TigerGraph cluster is a
localized change in one file, not a rewrite.

## Why the LLM never sets the risk score or picks the action

`risk_engine.py` and `policy_engine.py` are pure, deterministic functions.
The LLM (used only in `agent.py::_llm_explanation`, and only if
`ANTHROPIC_API_KEY` is set) receives the already-computed risk score,
evidence list, and action decision, and is only permitted to phrase a
natural-language explanation grounded in evidence IDs it was given — per the
system prompt's explicit rules. Without an API key, a deterministic
template produces the same structure, so the system is 100% functional with
zero external LLM calls.

## What is real vs. simulated in this prototype

| Component | Status |
|---|---|
| Investigation state machine, safety rails (max steps/rounds) | Real |
| Graph traversal logic (shared device/IP, similar cases, velocity) | Real (against in-memory graph; identical GSQL provided for TigerGraph) |
| Risk scoring, evidence breakdown | Real, deterministic |
| Policy engine / next-best-action table | Real, deterministic |
| RAG retrieval over policy & pattern docs | Real (TF-IDF cosine similarity) |
| Case persistence, audit log | Real (SQLite) |
| REST API, RBAC-by-static-key | Real |
| Dashboard, investigation view, graph viz, chat, admin page | Real, live-wired to the API |
| Step-up authentication / customer validation / analyst info request | Simulated (`mock_apis.py`) — clearly labeled |
| Action execution (block/freeze/etc.) | Simulated (`mock_apis.py`) — clearly labeled |
| TigerGraph cluster | Not connected in this build; real GSQL provided, `graph_engine.py` is the swap point |
| LLM explanation phrasing | Real if `ANTHROPIC_API_KEY` set; deterministic template fallback otherwise |
| Dataset | Synthetic, shaped like the IEEE-CIS/HHGOA column contract (see `data/sample/README.md`) — not the actual Kaggle dataset |

"""
Generates a small synthetic dataset SHAPED like the IEEE-CIS / HHGOA spec
described in the project brief: transactions carry a bank fraud-model risk
score (TransactionRiskScore) rather than a direct "isFraud" label, plus
customers, devices, IPs, merchants, closed historical cases, fraud policies,
fraud patterns and 20 benchmark cases.

This is clearly-labeled DEMO/SAMPLE data (see data/sample/README.md), not the
real IEEE-CIS Kaggle dataset. Swap in the real files at ingestion time and
backend/app/data_loader.py will pick them up as long as the column contract
in data/sample/README.md is respected.
"""
import csv
import json
import random
from datetime import datetime, timedelta
from pathlib import Path

random.seed(42)

OUT = Path(__file__).resolve().parent.parent / "data" / "sample"
OUT.mkdir(parents=True, exist_ok=True)

N_CUSTOMERS = 60
N_DEVICES = 25
N_IPS = 30
N_MERCHANTS = 20
N_TRANSACTIONS = 400

merchants = [f"M{1000+i}" for i in range(N_MERCHANTS)]
devices = [f"D{500+i}" for i in range(N_DEVICES)]
ips = [f"192.168.{i//255}.{i%255}" for i in range(N_IPS)]
customers = [f"C{2000+i}" for i in range(N_CUSTOMERS)]

# Deliberately make a handful of devices/IPs "hot" (shared by many customers)
hot_devices = random.sample(devices, 4)
hot_ips = random.sample(ips, 4)

customer_rows = []
for c in customers:
    customer_rows.append({
        "customer_id": c,
        "name": f"Customer_{c}",
        "account_id": f"A{c[1:]}",
        "email": f"{c.lower()}@example.com",
        "address": f"{random.randint(1,999)} MG Road, City{random.randint(1,9)}",
        "signup_date": (datetime(2025, 1, 1) + timedelta(days=random.randint(0, 200))).date().isoformat(),
    })

with open(OUT / "customers.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=customer_rows[0].keys())
    w.writeheader()
    w.writerows(customer_rows)

start = datetime(2026, 3, 1)
tx_rows = []
for i in range(N_TRANSACTIONS):
    cust = random.choice(customers)
    # 15% of transactions deliberately routed through a "hot" shared device/IP
    device = random.choice(hot_devices) if random.random() < 0.15 else random.choice(devices)
    ip = random.choice(hot_ips) if random.random() < 0.15 else random.choice(ips)
    merchant = random.choice(merchants)
    amount = round(random.expovariate(1 / 3000) + 50, 2)
    # bank fraud-model risk score: provided by the (simulated) upstream model,
    # correlated with hot device/ip usage and amount, but NOT a ground-truth label
    base = random.uniform(2, 25)
    if device in hot_devices:
        base += random.uniform(15, 30)
    if ip in hot_ips:
        base += random.uniform(10, 25)
    if amount > 8000:
        base += random.uniform(5, 15)
    risk_score = round(min(base, 99), 2)
    ts = start + timedelta(minutes=random.randint(0, 60 * 24 * 60))
    tx_rows.append({
        "transaction_id": f"TX{10000+i}",
        "customer_id": cust,
        "account_id": f"A{cust[1:]}",
        "device_id": device,
        "ip_address": ip,
        "merchant_id": merchant,
        "amount": amount,
        "currency": "INR",
        "timestamp": ts.isoformat(),
        "bank_risk_score": risk_score,
    })

with open(OUT / "transactions.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=tx_rows[0].keys())
    w.writeheader()
    w.writerows(tx_rows)

# Closed historical investigation cases (used for case-memory / similar-case retrieval)
patterns = ["shared_device", "shared_ip", "velocity_burst", "account_takeover", "merchant_collusion"]
outcomes = ["Confirmed Fraud", "Cleared"]
closed_cases = []
for i in range(35):
    tx = random.choice(tx_rows)
    closed_cases.append({
        "case_id": f"F-{9000+i}",
        "transaction_id": tx["transaction_id"],
        "customer_id": tx["customer_id"],
        "pattern": random.choice(patterns),
        "outcome": random.choice(outcomes),
        "risk_score_at_close": round(random.uniform(20, 95), 1),
        "closed_at": (start + timedelta(days=random.randint(30, 150))).date().isoformat(),
        "analyst_notes": "Synthetic historical case for demo case-memory.",
    })
with open(OUT / "closed_cases.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=closed_cases[0].keys())
    w.writeheader()
    w.writerows(closed_cases)

# Fraud policy documents (retrieved via RAG)
policies = [
    {
        "policy_id": "POL-001",
        "title": "Step-Up Authentication Requirement",
        "text": "Any transaction with risk score above 60 AND involvement of a device or IP "
                 "shared by 3 or more distinct customers requires step-up authentication "
                 "before further processing. Blocking without step-up authentication is not permitted "
                 "unless authentication has already failed.",
    },
    {
        "policy_id": "POL-002",
        "title": "Transaction Blocking Authorization",
        "text": "BLOCK_TRANSACTION may only be recommended when risk score exceeds 75 AND evidence "
                 "strength is HIGH AND (a) step-up authentication has failed, or (b) two or more "
                 "connected entities have a confirmed-fraud history. All blocks require Fraud Analyst approval.",
    },
    {
        "policy_id": "POL-003",
        "title": "Account Freezing",
        "text": "FREEZE_ACCOUNT is a high-impact action requiring Fraud Analyst approval and is only "
                 "permitted when at least two transactions on the account exceed risk score 80 within "
                 "a 24-hour window.",
    },
    {
        "policy_id": "POL-004",
        "title": "Evidence Sufficiency",
        "text": "An investigation may move to action recommendation only once confidence exceeds 0.75 "
                 "or the maximum evidence-gathering rounds have been exhausted, in which case the case "
                 "must be escalated to a human analyst rather than auto-resolved.",
    },
    {
        "policy_id": "POL-005",
        "title": "Low Risk Handling",
        "text": "Transactions with risk score below 30 and no suspicious connected-entity evidence "
                 "should be allowed and the case closed without analyst involvement, unless flagged "
                 "by a prior related case.",
    },
]
with open(OUT / "policies.json", "w") as f:
    json.dump(policies, f, indent=2)

# Fraud pattern typology documents (retrieved via RAG)
pattern_docs = [
    {"pattern": "shared_device", "description": "A device used by three or more distinct customers, "
     "especially when at least one of those customers has a confirmed fraud history. Suggests device "
     "farms, account takeover, or friendly-fraud rings."},
    {"pattern": "shared_ip", "description": "Multiple unrelated customers transacting from the same IP "
     "address in a short window. Suggests coordinated fraud or credential stuffing from a common origin."},
    {"pattern": "velocity_burst", "description": "An unusually high number of transactions from the same "
     "account within a short period, often preceding account takeover cash-out."},
    {"pattern": "account_takeover", "description": "A sudden change in device/IP/behavior for an "
     "established account, especially combined with a high-value transaction shortly after."},
    {"pattern": "merchant_collusion", "description": "Repeated transactions routed to the same merchant "
     "from otherwise-unconnected suspicious accounts, suggesting a compromised or colluding merchant."},
]
with open(OUT / "fraud_patterns.json", "w") as f:
    json.dump(pattern_docs, f, indent=2)

# 20 benchmark cases (final two months) -- pick 20 transactions with elevated risk
benchmark_txs = sorted(tx_rows, key=lambda r: -r["bank_risk_score"])[:20]
benchmark = [{"transaction_id": t["transaction_id"], "customer_id": t["customer_id"]} for t in benchmark_txs]
with open(OUT / "benchmark_cases.json", "w") as f:
    json.dump(benchmark, f, indent=2)

readme = """# Sample dataset (SYNTHETIC — not the real IEEE-CIS Kaggle data)

This folder is generated by scripts/generate_sample_data.py and is used only
so the prototype runs out of the box in DEMO_MODE. It mimics the column
contract described in the project spec:

- transactions.csv: transaction_id, customer_id, account_id, device_id,
  ip_address, merchant_id, amount, currency, timestamp, bank_risk_score
  (bank_risk_score is the upstream fraud-model score described in the spec —
  there is NO ground-truth is_fraud column, by design, matching the spec).
- customers.csv: customer_id, name, account_id, email, address, signup_date
- closed_cases.csv: historical resolved investigations used for case-memory /
  similar-case retrieval (case_id, transaction_id, customer_id, pattern,
  outcome, risk_score_at_close, closed_at, analyst_notes)
- policies.json: fraud policy documents retrieved via RAG
- fraud_patterns.json: fraud typology documents retrieved via RAG
- benchmark_cases.json: 20 benchmark transactions for evaluation/evaluate.py

To use the REAL IEEE-CIS-based HHGOA dataset: drop the real files into
data/raw/ with the same column names (or update backend/app/data_loader.py's
COLUMN_MAP) and set DEMO_MODE=false. The ingestion pipeline
(backend/app/data_loader.py) reads columns dynamically rather than assuming
fixed positions.
"""
with open(OUT / "README.md", "w") as f:
    f.write(readme)

print(f"Generated sample data in {OUT}")
print(f"  customers: {len(customer_rows)}  transactions: {len(tx_rows)}  closed_cases: {len(closed_cases)}")
print(f"  hot_devices={hot_devices}")
print(f"  hot_ips={hot_ips}")

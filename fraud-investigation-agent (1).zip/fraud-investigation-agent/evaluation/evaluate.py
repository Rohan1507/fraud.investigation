"""
python evaluate.py

Runs the investigation agent against every case in
data/sample/benchmark_cases.json (or your real benchmark file once you wire
in the actual IEEE-CIS/HHGOA benchmark set -- same schema: a list of
{"transaction_id": ..., "customer_id": ...}) and reports the metrics
requested in the spec.

IMPORTANT: this prototype's synthetic dataset has no ground-truth fraud
label (matching the spec's statement that the real dataset doesn't either),
so "accuracy" here is measured against internal consistency checks (does the
recommended action match what the deterministic policy engine would choose
given the computed risk/evidence; is every evidence id referenced in the
explanation actually present in the case; etc.) rather than a true
precision/recall against ground truth. When you plug in the real benchmark
set with analyst-confirmed outcomes, replace `_load_ground_truth()` below and
the script will compute real precision/recall/F1 automatically.
"""
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from app.graph_engine import graph_engine  # noqa: E402
from app import agent, config  # noqa: E402

BENCHMARK_PATH = config.SAMPLE_DIR / "benchmark_cases.json"
OUTPUT_PATH = Path(__file__).resolve().parent / "benchmark_results.json"


def _load_ground_truth():
    """No ground-truth labels are provided by the spec's dataset (by design).
    Return {} so accuracy metrics are reported as N/A rather than fabricated."""
    return {}


def evaluate():
    graph_engine.load_from_csv()
    with open(BENCHMARK_PATH) as f:
        benchmark = json.load(f)
    ground_truth = _load_ground_truth()

    results = []
    steps_list, times_list = [], []
    unnecessary_evidence_requests = 0
    explanation_gaps = 0

    for case_def in benchmark:
        tx_id = case_def["transaction_id"]
        t0 = time.time()
        try:
            case = agent.run_investigation(tx_id, "benchmark_evaluation")
        except ValueError as e:
            results.append({"transaction_id": tx_id, "error": str(e)})
            continue
        elapsed = time.time() - t0
        times_list.append(elapsed)
        steps_list.append(case["step_count"])

        evidence_ids = {e["id"] for e in case["evidence"]}
        explanation_ids = set((case.get("explanation") or {}).get("evidence_ids", []))
        if not explanation_ids.issubset(evidence_ids):
            explanation_gaps += 1

        # "unnecessary evidence request" heuristic: a step-up auth was requested
        # even though risk was already < 30 with no flagged connections going in
        if case.get("evidence_requests") and case["risk"]["risk_score"] < 30 \
                and not any(f for f in case["evidence"] if "confirmed fraud history" in f["description"]):
            unnecessary_evidence_requests += 1

        results.append({
            "case_id": case["case_id"],
            "transaction_id": tx_id,
            "customer_id": case["customer_id"],
            "risk_score": case["risk"]["risk_score"],
            "confidence": case["risk"]["confidence"],
            "fraud_pattern": case["fraud_pattern"],
            "evidence_count": len(case["evidence"]),
            "similar_cases_found": len(case["similar_cases"]),
            "recommended_action": case["recommended_action"]["action"],
            "approval_required": case["recommended_action"]["approval_required_role"],
            "status": case["status"],
            "investigation_steps": case["step_count"],
            "elapsed_seconds": round(elapsed, 4),
            "explanation_evidence_grounded": explanation_ids.issubset(evidence_ids),
        })

    metrics = {
        "total_benchmark_cases": len(benchmark),
        "cases_completed": len(results),
        "average_investigation_steps": round(statistics.mean(steps_list), 2) if steps_list else None,
        "average_response_time_seconds": round(statistics.mean(times_list), 4) if times_list else None,
        "explanation_completeness_pct": round(100 * (1 - explanation_gaps / max(len(results), 1)), 1),
        "unnecessary_evidence_requests": unnecessary_evidence_requests,
        "action_distribution": {},
        "note": "No ground-truth fraud labels exist in this dataset (by design, per spec) -- "
                "fraud-pattern-identification accuracy, false positive/negative rates and "
                "next-best-action accuracy against ground truth are reported as N/A. Supply "
                "analyst-confirmed outcomes in _load_ground_truth() to compute them for real.",
    }
    for r in results:
        a = r.get("recommended_action", "N/A")
        metrics["action_distribution"][a] = metrics["action_distribution"].get(a, 0) + 1

    if ground_truth:
        # Placeholder for when real labels are supplied
        tp = fp = fn = tn = 0
        for r in results:
            truth = ground_truth.get(r["transaction_id"])
            predicted_fraud = r["recommended_action"] in ("BLOCK_TRANSACTION", "FREEZE_ACCOUNT")
            if truth is None:
                continue
            if truth and predicted_fraud:
                tp += 1
            elif truth and not predicted_fraud:
                fn += 1
            elif not truth and predicted_fraud:
                fp += 1
            else:
                tn += 1
        precision = tp / (tp + fp) if (tp + fp) else None
        recall = tp / (tp + fn) if (tp + fn) else None
        metrics.update({"precision": precision, "recall": recall,
                         "false_positives": fp, "false_negatives": fn})

    output = {"metrics": metrics, "cases": results}
    with open(OUTPUT_PATH, "w") as f:
        json.dump(output, f, indent=2, default=str)

    print(json.dumps(metrics, indent=2))
    print(f"\nFull per-case results written to {OUTPUT_PATH}")


if __name__ == "__main__":
    evaluate()

"""
Case management & persistence.

Every case is stored as a JSON blob (full fidelity, matches models.Case)
alongside indexed columns for fast listing/filtering, in SQLite. Every
mutation is also appended to an audit_log table -- nothing about a case
changes silently.
"""
import json
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import config

config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = config.PROCESSED_DIR / "cases.db"


def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = _conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cases (
            case_id TEXT PRIMARY KEY,
            status TEXT,
            agent_state TEXT,
            risk_score REAL,
            transaction_id TEXT,
            customer_id TEXT,
            created_at TEXT,
            updated_at TEXT,
            data TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            case_id TEXT,
            timestamp TEXT,
            actor TEXT,
            event TEXT,
            detail TEXT
        )
    """)
    conn.commit()
    conn.close()


def new_case_id() -> str:
    return f"F-{uuid.uuid4().hex[:6].upper()}"


def save_case(case: Dict[str, Any]):
    conn = _conn()
    conn.execute("""
        INSERT INTO cases (case_id, status, agent_state, risk_score, transaction_id, customer_id,
                            created_at, updated_at, data)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(case_id) DO UPDATE SET
            status=excluded.status, agent_state=excluded.agent_state, risk_score=excluded.risk_score,
            updated_at=excluded.updated_at, data=excluded.data
    """, (
        case["case_id"], case["status"], case["agent_state"],
        (case.get("risk") or {}).get("risk_score"),
        case["transaction_id"], case.get("customer_id"),
        case["created_at"], case["updated_at"], json.dumps(case, default=str),
    ))
    conn.commit()
    conn.close()


def get_case(case_id: str) -> Optional[Dict[str, Any]]:
    conn = _conn()
    row = conn.execute("SELECT data FROM cases WHERE case_id=?", (case_id,)).fetchone()
    conn.close()
    return json.loads(row["data"]) if row else None


def list_cases(status: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = _conn()
    if status:
        rows = conn.execute("SELECT data FROM cases WHERE status=? ORDER BY updated_at DESC", (status,)).fetchall()
    else:
        rows = conn.execute("SELECT data FROM cases ORDER BY updated_at DESC").fetchall()
    conn.close()
    return [json.loads(r["data"]) for r in rows]


def log_audit(case_id: str, actor: str, event: str, detail: str = ""):
    conn = _conn()
    conn.execute(
        "INSERT INTO audit_log (case_id, timestamp, actor, event, detail) VALUES (?, ?, ?, ?, ?)",
        (case_id, datetime.utcnow().isoformat(), actor, event, detail),
    )
    conn.commit()
    conn.close()


def get_audit_log(case_id: str) -> List[Dict[str, Any]]:
    conn = _conn()
    rows = conn.execute(
        "SELECT timestamp, actor, event, detail FROM audit_log WHERE case_id=? ORDER BY id ASC", (case_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


init_db()

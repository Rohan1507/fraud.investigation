"""
Central configuration for the Fraud Investigation Agent backend.
All values are read from environment variables so no secrets are hard-coded.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent

# --- Mode flags -------------------------------------------------------------
DEMO_MODE: bool = os.getenv("DEMO_MODE", "true").lower() == "true"
TIGERGRAPH_AVAILABLE: bool = os.getenv("TIGERGRAPH_AVAILABLE", "false").lower() == "true"

# --- TigerGraph (used only when TIGERGRAPH_AVAILABLE=true) ------------------
TG_HOST = os.getenv("TG_HOST", "https://your-instance.i.tgcloud.io")
TG_USERNAME = os.getenv("TG_USERNAME", "")
TG_PASSWORD = os.getenv("TG_PASSWORD", "")
TG_GRAPH_NAME = os.getenv("TG_GRAPH_NAME", "FraudInvestigation")
TG_SECRET = os.getenv("TG_SECRET", "")

# --- LLM ----------------------------------------------------------------
# If ANTHROPIC_API_KEY is not set, the agent falls back to deterministic,
# template-based explanations (fully functional, just not LLM-phrased).
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-4-6")

# --- App / DB -------------------------------------------------------------
SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-change-me")
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR}/data/processed/cases.db")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "480"))

# --- Agent limits (safety rails against infinite loops) ---------------------
MAX_INVESTIGATION_STEPS = int(os.getenv("MAX_INVESTIGATION_STEPS", "8"))
MAX_EVIDENCE_ROUNDS = int(os.getenv("MAX_EVIDENCE_ROUNDS", "2"))
CONFIDENCE_SUFFICIENT_THRESHOLD = float(os.getenv("CONFIDENCE_SUFFICIENT_THRESHOLD", "0.75"))

# --- Risk thresholds (configurable, shown on Admin page) --------------------
RISK_LOW_MAX = int(os.getenv("RISK_LOW_MAX", "30"))
RISK_MEDIUM_MAX = int(os.getenv("RISK_MEDIUM_MAX", "70"))

DATA_DIR = BASE_DIR / "data"
SAMPLE_DIR = DATA_DIR / "sample"
PROCESSED_DIR = DATA_DIR / "processed"

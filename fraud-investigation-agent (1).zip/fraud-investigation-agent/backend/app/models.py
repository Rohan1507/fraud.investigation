"""Pydantic schemas used across the API."""
from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


# ---------------------------------------------------------------- Enums ----
class CaseStatus(str, Enum):
    OPEN = "OPEN"
    INVESTIGATING = "INVESTIGATING"
    WAITING_FOR_EVIDENCE = "WAITING_FOR_EVIDENCE"
    WAITING_FOR_APPROVAL = "WAITING_FOR_APPROVAL"
    ACTION_TAKEN = "ACTION_TAKEN"
    RESOLVED = "RESOLVED"
    ESCALATED = "ESCALATED"
    CLOSED = "CLOSED"


class AgentState(str, Enum):
    TRIGGERED = "TRIGGERED"
    CASE_CREATED = "CASE_CREATED"
    INVESTIGATING = "INVESTIGATING"
    EVIDENCE_GATHERING = "EVIDENCE_GATHERING"
    RISK_ASSESSMENT = "RISK_ASSESSMENT"
    UNCERTAINTY_CHECK = "UNCERTAINTY_CHECK"
    MORE_EVIDENCE_REQUIRED = "MORE_EVIDENCE_REQUIRED"
    REASSESSMENT = "REASSESSMENT"
    ACTION_RECOMMENDATION = "ACTION_RECOMMENDATION"
    HUMAN_APPROVAL = "HUMAN_APPROVAL"
    ACTION_EXECUTION = "ACTION_EXECUTION"
    CASE_RESOLUTION = "CASE_RESOLUTION"
    MEMORY_UPDATE = "MEMORY_UPDATE"


class EvidenceStrength(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class ActionType(str, Enum):
    ALLOW_TRANSACTION = "ALLOW_TRANSACTION"
    BLOCK_TRANSACTION = "BLOCK_TRANSACTION"
    MONITOR_ACCOUNT = "MONITOR_ACCOUNT"
    WARN_CUSTOMER = "WARN_CUSTOMER"
    REQUEST_MORE_EVIDENCE = "REQUEST_MORE_EVIDENCE"
    REQUEST_STEP_UP_AUTHENTICATION = "REQUEST_STEP_UP_AUTHENTICATION"
    ESCALATE_TO_ANALYST = "ESCALATE_TO_ANALYST"
    FREEZE_ACCOUNT = "FREEZE_ACCOUNT"
    CLOSE_CASE = "CLOSE_CASE"


class Role(str, Enum):
    ANALYST = "analyst"
    ADMIN = "admin"
    READ_ONLY = "read_only"


# ------------------------------------------------------------- Requests ----
class InvestigationTriggerRequest(BaseModel):
    transaction_id: str
    reason: str = "manual_trigger"


class ApprovalRequest(BaseModel):
    approved_by: str
    notes: Optional[str] = None


class EvidenceRequestPayload(BaseModel):
    evidence_type: str  # e.g. "step_up_auth", "customer_validation", "analyst_info"
    requested_by: str = "agent"


class ChatMessage(BaseModel):
    case_id: Optional[str] = None
    message: str


# ------------------------------------------------------------- Responses ---
class EvidenceItem(BaseModel):
    id: str
    description: str
    source: str
    confidence: float
    obtained_at: datetime


class RiskBreakdown(BaseModel):
    label: str
    points: float
    reason: str


class RiskAssessment(BaseModel):
    risk_score: float
    confidence: float
    evidence_strength: EvidenceStrength
    investigation_status: str
    breakdown: List[RiskBreakdown]


class ActionRecommendation(BaseModel):
    action: ActionType
    reason: str
    approval_required_role: Optional[Role]
    executed: bool = False


class TimelineEvent(BaseModel):
    timestamp: datetime
    event: str
    detail: Optional[str] = None


class SimilarCase(BaseModel):
    case_id: str
    similarity: float
    pattern: str
    outcome: str


class ExplainabilityOutput(BaseModel):
    risk_score: float
    confidence: float
    fraud_pattern: Optional[str]
    evidence_ids: List[str]
    uncertainty: List[str]
    recommended_action: ActionType
    reason: str


class Case(BaseModel):
    case_id: str
    status: CaseStatus
    agent_state: AgentState
    transaction_id: str
    customer_id: Optional[str]
    trigger_reason: str
    risk: Optional[RiskAssessment] = None
    fraud_pattern: Optional[str] = None
    evidence: List[EvidenceItem] = Field(default_factory=list)
    timeline: List[TimelineEvent] = Field(default_factory=list)
    similar_cases: List[SimilarCase] = Field(default_factory=list)
    recommended_action: Optional[ActionRecommendation] = None
    explanation: Optional[ExplainabilityOutput] = None
    approval_status: Optional[str] = None
    analyst_notes: List[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime
    step_count: int = 0

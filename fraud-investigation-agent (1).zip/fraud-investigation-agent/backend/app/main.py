"""
FastAPI app exposing the fraud investigation system.

Auth model (prototype-grade, documented limitation): a static API-key -> role
map read from environment variables, sent as `X-API-Key` + `X-Role` headers.
This gives real role-based access control for the prototype without the
complexity of full OAuth/JWT user management, which is out of scope for a
single-session build. Swap `get_current_role` for real JWT auth for production.
"""
import os
import re
from typing import Optional

from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware

from . import config, case_manager, agent
from .graph_engine import graph_engine
from .rag import rag_index
from .models import ApprovalRequest, EvidenceRequestPayload, InvestigationTriggerRequest, ChatMessage, Role
from .policy_engine import ACTION_POLICY_TABLE
from .risk_engine import WEIGHTS, VELOCITY_THRESHOLD, LARGE_AMOUNT_THRESHOLD

app = FastAPI(title="AI Agentic Fraud Investigation & Next-Best-Action System", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # prototype only -- restrict in production
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- simple static RBAC (see module docstring) ------------------------------
API_KEYS = {
    os.getenv("API_KEY_ANALYST", "analyst-key"): Role.ANALYST,
    os.getenv("API_KEY_ADMIN", "admin-key"): Role.ADMIN,
    os.getenv("API_KEY_READONLY", "readonly-key"): Role.READ_ONLY,
}


def get_current_role(x_api_key: Optional[str] = Header(default=None)) -> Role:
    if config.DEMO_MODE and x_api_key is None:
        return Role.ANALYST  # frictionless demo; disable by setting DEMO_MODE=false
    role = API_KEYS.get(x_api_key or "")
    if role is None:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
    return role


def require_write(role: Role = Depends(get_current_role)) -> Role:
    if role == Role.READ_ONLY:
        raise HTTPException(status_code=403, detail="Read-only role cannot perform this action")
    return role


@app.on_event("startup")
def startup():
    stats = graph_engine.load_from_csv()
    print("Graph loaded:", stats)


# --------------------------------------------------------------- health -----
@app.get("/api/health")
def health():
    return {"status": "ok", "demo_mode": config.DEMO_MODE,
            "tigergraph_available": config.TIGERGRAPH_AVAILABLE,
            "llm_configured": bool(config.ANTHROPIC_API_KEY),
            "graph_stats": graph_engine.stats}


# --------------------------------------------------------- investigations --
@app.post("/api/investigations")
def trigger_investigation(payload: InvestigationTriggerRequest, role: Role = Depends(require_write)):
    try:
        case = agent.run_investigation(payload.transaction_id, payload.reason)
        return case
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.get("/api/investigations/{case_id}")
def get_investigation(case_id: str, role: Role = Depends(get_current_role)):
    case = case_manager.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="case not found")
    return case


# ----------------------------------------------------------------- cases ---
@app.get("/api/cases")
def list_cases(status: Optional[str] = None, role: Role = Depends(get_current_role)):
    return case_manager.list_cases(status)


@app.get("/api/cases/{case_id}")
def get_case(case_id: str, role: Role = Depends(get_current_role)):
    case = case_manager.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="case not found")
    return case


@app.get("/api/cases/{case_id}/evidence")
def get_case_evidence(case_id: str, role: Role = Depends(get_current_role)):
    case = case_manager.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="case not found")
    return {"evidence": case.get("evidence", []), "evidence_requests": case.get("evidence_requests", [])}


@app.get("/api/cases/{case_id}/graph")
def get_case_graph(case_id: str, role: Role = Depends(get_current_role)):
    case = case_manager.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="case not found")
    tx_id = case["transaction_id"]
    connected = graph_engine.get_connected_entities(tx_id)
    nodes = [{"id": tx_id, "type": "Transaction"}, {"id": case["customer_id"], "type": "Customer"}]
    edges = [{"source": case["customer_id"], "target": tx_id, "type": "PERFORMED"}]
    if connected.get("device_id"):
        nodes.append({"id": connected["device_id"], "type": "Device"})
        edges.append({"source": tx_id, "target": connected["device_id"], "type": "USED_DEVICE"})
        for c in connected.get("customers_sharing_device", []):
            flagged = any(f["customer_id"] == c for f in connected.get("flagged_connected_customers", []))
            nodes.append({"id": c, "type": "Customer", "flagged": flagged})
            edges.append({"source": c, "target": connected["device_id"], "type": "USES_DEVICE"})
    if connected.get("ip_address"):
        nodes.append({"id": connected["ip_address"], "type": "IPAddress"})
        edges.append({"source": tx_id, "target": connected["ip_address"], "type": "FROM_IP"})
        for c in connected.get("customers_sharing_ip", []):
            flagged = any(f["customer_id"] == c for f in connected.get("flagged_connected_customers", []))
            nodes.append({"id": c, "type": "Customer", "flagged": flagged})
            edges.append({"source": c, "target": connected["ip_address"], "type": "USES_IP"})
    # de-dup nodes by id
    seen, deduped = set(), []
    for n in nodes:
        if n["id"] not in seen:
            seen.add(n["id"])
            deduped.append(n)
    return {"nodes": deduped, "edges": edges}


@app.get("/api/cases/{case_id}/audit-log")
def get_audit_log(case_id: str, role: Role = Depends(get_current_role)):
    return case_manager.get_audit_log(case_id)


@app.post("/api/cases/{case_id}/evidence/request")
def request_evidence(case_id: str, payload: EvidenceRequestPayload, role: Role = Depends(require_write)):
    try:
        return agent.request_more_evidence(case_id, payload.evidence_type, payload.requested_by)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.post("/api/cases/{case_id}/approve")
def approve(case_id: str, payload: ApprovalRequest, role: Role = Depends(get_current_role)):
    if role != Role.ANALYST and role != Role.ADMIN:
        raise HTTPException(status_code=403, detail="Only an Analyst or Admin can approve/reject actions")
    try:
        return agent.approve_action(case_id, payload.approved_by, approve=True, notes=payload.notes)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/cases/{case_id}/reject")
def reject(case_id: str, payload: ApprovalRequest, role: Role = Depends(get_current_role)):
    if role != Role.ANALYST and role != Role.ADMIN:
        raise HTTPException(status_code=403, detail="Only an Analyst or Admin can approve/reject actions")
    try:
        return agent.approve_action(case_id, payload.approved_by, approve=False, notes=payload.notes)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/cases/{case_id}/escalate")
def escalate(case_id: str, payload: ApprovalRequest, role: Role = Depends(require_write)):
    try:
        return agent.escalate_case(case_id, payload.approved_by, payload.notes)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ------------------------------------------------------------- lookups -----
@app.get("/api/transactions/{transaction_id}")
def get_transaction(transaction_id: str, role: Role = Depends(get_current_role)):
    tx = graph_engine.get_transaction(transaction_id)
    if not tx:
        raise HTTPException(status_code=404, detail="transaction not found")
    return tx


@app.get("/api/customers/{customer_id}")
def get_customer(customer_id: str, role: Role = Depends(get_current_role)):
    cust = graph_engine.get_customer_profile(customer_id)
    if not cust:
        raise HTTPException(status_code=404, detail="customer not found")
    return cust


@app.get("/api/patterns")
def get_patterns(role: Role = Depends(get_current_role)):
    return rag_index.patterns


@app.get("/api/policies")
def get_policies(role: Role = Depends(get_current_role)):
    return {"documents": rag_index.policies, "action_policy_table": [
        {**{k: (v.value if hasattr(v, "value") else v) for k, v in rule.items()}} for rule in ACTION_POLICY_TABLE
    ]}


@app.get("/api/admin/config")
def get_admin_config(role: Role = Depends(get_current_role)):
    if role != Role.ADMIN:
        raise HTTPException(status_code=403, detail="Admin role required")
    return {
        "risk_weights": WEIGHTS,
        "velocity_threshold": VELOCITY_THRESHOLD,
        "large_amount_threshold": LARGE_AMOUNT_THRESHOLD,
        "risk_bands": {"low_max": config.RISK_LOW_MAX, "medium_max": config.RISK_MEDIUM_MAX},
        "max_investigation_steps": config.MAX_INVESTIGATION_STEPS,
        "max_evidence_rounds": config.MAX_EVIDENCE_ROUNDS,
        "confidence_sufficient_threshold": config.CONFIDENCE_SUFFICIENT_THRESHOLD,
    }


@app.get("/api/similar-cases")
def similar_cases(transaction_id: str, role: Role = Depends(get_current_role)):
    return graph_engine.find_similar_historical_cases(transaction_id)


# ------------------------------------------------------------------ chat ---
_TX_PATTERN = re.compile(r"\bTX\d+\b", re.IGNORECASE)


@app.post("/api/chat")
def chat(payload: ChatMessage, role: Role = Depends(get_current_role)):
    """A real investigation assistant grounded in the actual case/graph state
    -- not a canned chatbot. If the message names a transaction, it triggers
    (or reuses) a real investigation and summarizes the real result."""
    msg = payload.message

    if payload.case_id:
        case = case_manager.get_case(payload.case_id)
        if not case:
            return {"reply": f"I couldn't find case {payload.case_id}."}
        risk = case.get("risk") or {}
        return {"reply": (
            f"Case {case['case_id']} is currently {case['status']} (state: {case['agent_state']}).\n"
            f"Risk score: {risk.get('risk_score')}/100, confidence {risk.get('confidence')}.\n"
            f"Recommended action: {(case.get('recommended_action') or {}).get('action')}.\n"
            f"Reason: {(case.get('recommended_action') or {}).get('reason')}"
        ), "case": case}

    match = _TX_PATTERN.search(msg)
    if match:
        tx_id = match.group(0).upper()
        existing = [c for c in case_manager.list_cases() if c["transaction_id"] == tx_id]
        if existing:
            case = existing[0]
        else:
            try:
                case = agent.run_investigation(tx_id, "chat_trigger")
            except ValueError as e:
                return {"reply": str(e)}
        risk = case.get("risk") or {}
        flagged = sum(len(f) for f in [case.get("evidence", [])])
        return {"reply": (
            f"I opened Case {case['case_id']}.\n\n"
            f"Initial risk: {risk.get('risk_score')}/100 (confidence {risk.get('confidence')}).\n"
            f"Fraud pattern: {case.get('fraud_pattern') or 'none clearly matched'}.\n"
            f"Evidence items gathered: {len(case.get('evidence', []))}.\n"
            f"Similar historical cases found: {len(case.get('similar_cases', []))}.\n\n"
            f"Recommended next action: {(case.get('recommended_action') or {}).get('action')}\n"
            f"Reason: {(case.get('recommended_action') or {}).get('reason')}"
        ), "case": case}

    return {"reply": "Tell me a transaction ID (e.g. \"Investigate transaction TX10045\") "
                      "or a case ID to get a status update."}

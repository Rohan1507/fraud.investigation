"""
Investigation agent: explicit state machine, NOT a free-form chatbot.

Flow (per spec):
TRIGGERED -> CASE_CREATED -> INVESTIGATING -> EVIDENCE_GATHERING ->
RISK_ASSESSMENT -> UNCERTAINTY_CHECK -> [MORE_EVIDENCE_REQUIRED -> REASSESSMENT]* ->
ACTION_RECOMMENDATION -> HUMAN_APPROVAL -> ACTION_EXECUTION -> CASE_RESOLUTION -> MEMORY_UPDATE

Safety rails: MAX_INVESTIGATION_STEPS and MAX_EVIDENCE_ROUNDS (config.py) put a
hard ceiling on how many times the agent can loop back for more evidence,
so this can never become an infinite agent loop. Every tool call and state
transition is appended to the case timeline for full auditability.

The LLM (if ANTHROPIC_API_KEY is set) is used ONLY to phrase the
already-computed, structured explanation in natural language -- it never
sets the risk score or picks the action. Every fact it is allowed to use is
handed to it explicitly; it is instructed never to invent evidence.
"""
import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from . import config, case_manager, mock_apis
from .graph_engine import graph_engine
from .rag import rag_index
from .risk_engine import compute_risk
from .policy_engine import decide_next_action, ACTION_POLICY_TABLE
from .models import AgentState, CaseStatus, EvidenceStrength, ActionType, Role


SYSTEM_PROMPT = """You are a fraud investigation explanation assistant.
Rules you MUST follow:
1. Never invent evidence. Only use facts given to you in the CONTEXT block.
2. Every important conclusion must reference an evidence id from the CONTEXT.
3. Use graph evidence before making relationship claims.
4. Follow the fraud policies given to you; do not recommend actions yourself
   (the action has already been decided by the policy engine -- you only explain it).
5. Explicitly represent uncertainty listed in the CONTEXT.
6. Distinguish facts from hypotheses.
7. Never claim a transaction is fraudulent solely because of a high risk score.
8. Do not reveal step-by-step reasoning; return only the structured explanation requested.
Return your answer as a short JSON object: {"summary": "...", "why_suspicious": "...",
"uncertainty_note": "..."} and nothing else -- no markdown fences.
"""


def _timeline_event(event: str, detail: str = "") -> Dict[str, Any]:
    return {"timestamp": datetime.utcnow().isoformat(), "event": event, "detail": detail}


def _template_explanation(evidence_ids: List[str], risk_score: float, pattern: Optional[str],
                           uncertainty: List[str], action: str) -> Dict[str, str]:
    """Deterministic fallback used whenever no LLM key is configured (DEMO_MODE default)."""
    return {
        "summary": f"Risk score {risk_score}/100 based on evidence {evidence_ids}"
                    + (f", matching the '{pattern}' pattern." if pattern else "."),
        "why_suspicious": "Connected-entity and historical-case evidence above indicate elevated risk; "
                           "see the risk breakdown for exact point attribution.",
        "uncertainty_note": "; ".join(uncertainty) if uncertainty else "No major uncertainty flagged.",
    }


def _llm_explanation(context: Dict[str, Any]) -> Dict[str, str]:
    if not config.ANTHROPIC_API_KEY:
        return _template_explanation(
            context["evidence_ids"], context["risk_score"], context.get("fraud_pattern"),
            context["uncertainty"], context["recommended_action"])
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
        msg = client.messages.create(
            model=config.LLM_MODEL,
            max_tokens=400,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": f"CONTEXT:\n{json.dumps(context, default=str)}"}],
        )
        text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
        return json.loads(text)
    except Exception as e:  # noqa: BLE001 -- never let explanation failures break the investigation
        fallback = _template_explanation(
            context["evidence_ids"], context["risk_score"], context.get("fraud_pattern"),
            context["uncertainty"], context["recommended_action"])
        fallback["llm_error"] = str(e)
        return fallback


def _infer_pattern(connected: Dict[str, Any], velocity_flag: bool) -> Optional[str]:
    if connected.get("flagged_connected_customers") and connected.get("customers_sharing_device"):
        return "shared_device"
    if connected.get("flagged_connected_customers") and connected.get("customers_sharing_ip"):
        return "shared_ip"
    if velocity_flag:
        return "velocity_burst"
    if connected.get("customers_sharing_device") or connected.get("customers_sharing_ip"):
        return "shared_device" if connected.get("customers_sharing_device") else "shared_ip"
    return None


def run_investigation(transaction_id: str, trigger_reason: str = "manual_trigger") -> Dict[str, Any]:
    """Runs the FULL state machine synchronously and returns the resulting case.
    (Kept synchronous/deterministic-stepwise so every state transition is easy
    to unit test individually -- see backend/tests/test_agent.py.)"""

    tx = graph_engine.get_transaction(transaction_id)
    if tx is None:
        raise ValueError(f"Transaction {transaction_id} not found in graph")

    case_id = case_manager.new_case_id()
    now = datetime.utcnow().isoformat()
    case: Dict[str, Any] = {
        "case_id": case_id,
        "status": CaseStatus.OPEN.value,
        "agent_state": AgentState.TRIGGERED.value,
        "transaction_id": transaction_id,
        "customer_id": tx.get("customer_id"),
        "trigger_reason": trigger_reason,
        "risk": None,
        "fraud_pattern": None,
        "evidence": [],
        "timeline": [_timeline_event("TRIGGER_RECEIVED", f"transaction_id={transaction_id}, reason={trigger_reason}")],
        "similar_cases": [],
        "recommended_action": None,
        "explanation": None,
        "approval_status": None,
        "analyst_notes": [],
        "created_at": now,
        "updated_at": now,
        "step_count": 0,
    }

    def advance(state: AgentState, event: str, detail: str = ""):
        case["agent_state"] = state.value
        case["timeline"].append(_timeline_event(event, detail))
        case["step_count"] += 1
        case["updated_at"] = datetime.utcnow().isoformat()

    # CASE_CREATED
    advance(AgentState.CASE_CREATED, "CASE_CREATED", f"Case {case_id} opened for {transaction_id}")
    case["status"] = CaseStatus.INVESTIGATING.value
    case_manager.log_audit(case_id, "agent", "CASE_CREATED", transaction_id)

    ownership_verified = False
    step_up_failed = False
    evidence_round = 0

    while True:
        # INVESTIGATING -> pull connected entities & customer profile
        advance(AgentState.INVESTIGATING, "TRANSACTION_ANALYZED", f"Analyzing {transaction_id}")
        connected = graph_engine.get_connected_entities(transaction_id)
        velocity = graph_engine.get_transaction_velocity(tx["customer_id"])
        velocity_flag = velocity >= 12

        if connected.get("customers_sharing_device") or connected.get("customers_sharing_ip"):
            advance(AgentState.INVESTIGATING, "RELATIONSHIP_DISCOVERED",
                    f"device_customers={connected.get('customers_sharing_device')}, "
                    f"ip_customers={connected.get('customers_sharing_ip')}")

        # EVIDENCE_GATHERING -> similar historical cases (case memory / GraphRAG)
        advance(AgentState.EVIDENCE_GATHERING, "SEARCHING_SIMILAR_CASES")
        similar_cases = graph_engine.find_similar_historical_cases(transaction_id)
        if similar_cases:
            advance(AgentState.EVIDENCE_GATHERING, "SIMILAR_CASE_FOUND",
                    f"{len(similar_cases)} similar case(s): {[c['case_id'] for c in similar_cases]}")
        case["similar_cases"] = similar_cases

        policy_hits = rag_index.retrieve_policies(
            f"risk transaction device ip shared evidence {connected.get('device_id')}")
        pattern_hits = rag_index.retrieve_patterns("shared device ip velocity account takeover merchant")

        # Build evidence log with stable IDs
        evidence_items = []
        eid = 100
        for label, desc, src, conf in [
            ("bank_risk_score", f"Bank fraud-model risk score: {tx.get('bank_risk_score')}", "transaction", 0.9),
            ("device", f"Transaction used device {connected.get('device_id')}", "graph", 0.95),
            ("ip", f"Transaction originated from IP {connected.get('ip_address')}", "graph", 0.95),
        ]:
            eid += 1
            evidence_items.append({"id": f"E{eid}", "description": desc, "source": src,
                                    "confidence": conf, "obtained_at": datetime.utcnow().isoformat()})
        for f in connected.get("flagged_connected_customers", []):
            eid += 1
            evidence_items.append({
                "id": f"E{eid}",
                "description": f"Connected customer {f['customer_id']} has confirmed fraud history: {f['history']}",
                "source": "graph", "confidence": 0.85, "obtained_at": datetime.utcnow().isoformat(),
            })
        for c in similar_cases:
            eid += 1
            evidence_items.append({
                "id": f"E{eid}",
                "description": f"Similar historical case {c['case_id']} ({c['pattern']}) outcome={c['outcome']}, "
                                f"similarity={c['similarity']}",
                "source": "case_memory", "confidence": c["similarity"], "obtained_at": datetime.utcnow().isoformat(),
            })
        case["evidence"] = evidence_items

        # RISK_ASSESSMENT
        advance(AgentState.RISK_ASSESSMENT, "RISK_CALCULATED")
        risk = compute_risk(tx, connected, velocity, similar_cases)
        case["risk"] = {
            "risk_score": risk.risk_score, "confidence": risk.confidence,
            "evidence_strength": risk.evidence_strength.value,
            "investigation_status": risk.investigation_status,
            "breakdown": [b.__dict__ for b in risk.breakdown],
        }
        case["fraud_pattern"] = _infer_pattern(connected, velocity_flag)
        advance(AgentState.RISK_ASSESSMENT, "RISK_REASSESSED" if evidence_round else "RISK_SCORED",
                f"score={risk.risk_score} confidence={risk.confidence} strength={risk.evidence_strength.value}")

        # UNCERTAINTY_CHECK
        advance(AgentState.UNCERTAINTY_CHECK, "UNCERTAINTY_EVALUATED",
                f"status={risk.investigation_status}")

        rounds_exhausted = evidence_round >= config.MAX_EVIDENCE_ROUNDS
        # POL-005: low risk with no suspicious connected-entity evidence should be
        # allowed/closed without further evidence-gathering, regardless of confidence math.
        is_low_risk_clean = (risk.risk_score < config.RISK_LOW_MAX
                              and not connected.get("flagged_connected_customers")
                              and not similar_cases)
        if risk.investigation_status != "Sufficient Evidence" and not rounds_exhausted \
                and not is_low_risk_clean \
                and case["step_count"] < config.MAX_INVESTIGATION_STEPS:
            # MORE_EVIDENCE_REQUIRED -> gather more (simulated step-up auth) -> REASSESSMENT
            advance(AgentState.MORE_EVIDENCE_REQUIRED, "MORE_EVIDENCE_REQUIRED",
                    "Confidence below sufficiency threshold; requesting step-up authentication")
            case["status"] = CaseStatus.WAITING_FOR_EVIDENCE.value
            auth_result = mock_apis.mock_request_step_up_authentication(tx["customer_id"], transaction_id)
            case.setdefault("evidence_requests", []).append(auth_result)
            ownership_verified = auth_result["response"] == "AUTHENTICATED"
            step_up_failed = auth_result["response"] == "FAILED"
            advance(AgentState.MORE_EVIDENCE_REQUIRED, "STEP_UP_AUTH_RESPONSE_RECEIVED",
                    f"response={auth_result['response']}")
            evidence_round += 1
            advance(AgentState.REASSESSMENT, "REASSESSING_WITH_NEW_EVIDENCE")
            case["status"] = CaseStatus.INVESTIGATING.value
            continue  # loop back to re-run investigation/risk with new evidence
        break

    n_confirmed_links = sum(1 for f in connected.get("flagged_connected_customers", []))

    # ACTION_RECOMMENDATION
    advance(AgentState.ACTION_RECOMMENDATION, "ACTION_RECOMMENDATION_STARTED")
    decision = decide_next_action(
        risk_score=risk.risk_score, confidence=risk.confidence, evidence_strength=risk.evidence_strength,
        ownership_verified=ownership_verified, step_up_failed=step_up_failed,
        n_confirmed_fraud_links=n_confirmed_links,
        evidence_rounds_exhausted=(evidence_round >= config.MAX_EVIDENCE_ROUNDS
                                    and risk.investigation_status != "Sufficient Evidence"),
    )
    case["recommended_action"] = {
        "action": decision.action.value, "reason": decision.reason,
        "approval_required_role": decision.approval_required_role.value if decision.approval_required_role else None,
        "executed": False,
    }
    advance(AgentState.ACTION_RECOMMENDATION, "ACTION_RECOMMENDED", decision.action.value)

    uncertainty = []
    if not ownership_verified:
        uncertainty.append("Transaction ownership by the account holder is not fully confirmed")
    if risk.confidence < 0.9:
        uncertainty.append("Some connected-entity relationships may reflect legitimate shared infrastructure")
    if not similar_cases:
        uncertainty.append("No closely similar historical case was found to corroborate the pattern")

    explanation_context = {
        "risk_score": risk.risk_score, "confidence": risk.confidence,
        "fraud_pattern": case["fraud_pattern"],
        "evidence_ids": [e["id"] for e in evidence_items],
        "evidence": evidence_items,
        "policies": policy_hits, "patterns": pattern_hits,
        "similar_cases": similar_cases,
        "uncertainty": uncertainty,
        "recommended_action": decision.action.value,
        "recommended_action_reason": decision.reason,
    }
    explanation_text = _llm_explanation(explanation_context)
    case["explanation"] = {
        "risk_score": risk.risk_score, "confidence": risk.confidence,
        "fraud_pattern": case["fraud_pattern"], "evidence_ids": [e["id"] for e in evidence_items],
        "uncertainty": uncertainty, "recommended_action": decision.action.value,
        "reason": explanation_text.get("summary", decision.reason),
        "why_suspicious": explanation_text.get("why_suspicious"),
        "uncertainty_note": explanation_text.get("uncertainty_note"),
    }
    advance(AgentState.ACTION_RECOMMENDATION, "EXPLANATION_GENERATED")

    # HUMAN_APPROVAL gate
    if decision.approval_required_role:
        advance(AgentState.HUMAN_APPROVAL, "AWAITING_HUMAN_APPROVAL", decision.approval_required_role.value)
        case["status"] = CaseStatus.WAITING_FOR_APPROVAL.value
        case["approval_status"] = "PENDING"
    elif decision.action == ActionType.ESCALATE_TO_ANALYST:
        advance(AgentState.CASE_RESOLUTION, "ESCALATED_TO_ANALYST")
        case["status"] = CaseStatus.ESCALATED.value
    else:
        # low/medium-impact actions can auto-execute per policy
        advance(AgentState.ACTION_EXECUTION, "ACTION_AUTO_EXECUTED", decision.action.value)
        exec_result = mock_apis.mock_execute_action(decision.action.value, case_id, transaction_id)
        case.setdefault("execution_log", []).append(exec_result)
        case["recommended_action"]["executed"] = True
        advance(AgentState.CASE_RESOLUTION, "CASE_RESOLVED")
        case["status"] = CaseStatus.RESOLVED.value

    # MEMORY_UPDATE
    advance(AgentState.MEMORY_UPDATE, "CASE_MEMORY_UPDATED",
            "Case recorded for future similar-case retrieval")

    case_manager.save_case(case)
    case_manager.log_audit(case_id, "agent", "INVESTIGATION_COMPLETE", case["agent_state"])
    return case


def approve_action(case_id: str, approved_by: str, approve: bool, notes: Optional[str] = None) -> Dict[str, Any]:
    case = case_manager.get_case(case_id)
    if case is None:
        raise ValueError("case not found")
    if case.get("approval_status") != "PENDING":
        raise ValueError("case is not awaiting approval")

    case["timeline"].append(_timeline_event(
        "APPROVAL_DECISION_RECEIVED", f"by={approved_by} decision={'APPROVE' if approve else 'REJECT'}"))
    if notes:
        case["analyst_notes"].append(f"{approved_by}: {notes}")

    if approve:
        case["approval_status"] = "APPROVED"
        action = case["recommended_action"]["action"]
        exec_result = mock_apis.mock_execute_action(action, case_id, case["transaction_id"])
        case.setdefault("execution_log", []).append(exec_result)
        case["recommended_action"]["executed"] = True
        case["agent_state"] = AgentState.ACTION_EXECUTION.value
        case["timeline"].append(_timeline_event("ACTION_EXECUTED", action))
        case["status"] = CaseStatus.ACTION_TAKEN.value
        case["agent_state"] = AgentState.CASE_RESOLUTION.value
        case["timeline"].append(_timeline_event("CASE_RESOLVED"))
        case["status"] = CaseStatus.RESOLVED.value
    else:
        case["approval_status"] = "REJECTED"
        case["status"] = CaseStatus.CLOSED.value
        case["agent_state"] = AgentState.CASE_RESOLUTION.value
        case["timeline"].append(_timeline_event("CASE_CLOSED_ON_REJECTION"))

    case["updated_at"] = datetime.utcnow().isoformat()
    case_manager.save_case(case)
    case_manager.log_audit(case_id, approved_by, "APPROVAL_DECISION", "approved" if approve else "rejected")
    return case


def request_more_evidence(case_id: str, evidence_type: str, requested_by: str) -> Dict[str, Any]:
    case = case_manager.get_case(case_id)
    if case is None:
        raise ValueError("case not found")
    if evidence_type == "customer_validation":
        result = mock_apis.mock_request_customer_validation(case["transaction_id"])
    elif evidence_type == "step_up_auth":
        result = mock_apis.mock_request_step_up_authentication(case["customer_id"], case["transaction_id"])
    else:
        result = mock_apis.mock_request_additional_information(case_id)
    case.setdefault("evidence_requests", []).append(result)
    case["timeline"].append(_timeline_event("EVIDENCE_REQUESTED", f"{evidence_type} by {requested_by}"))
    case["timeline"].append(_timeline_event("EVIDENCE_RESPONSE_RECEIVED", str(result.get("response"))))
    case["updated_at"] = datetime.utcnow().isoformat()
    case_manager.save_case(case)
    case_manager.log_audit(case_id, requested_by, "EVIDENCE_REQUESTED", evidence_type)
    return case


def escalate_case(case_id: str, escalated_by: str, notes: Optional[str] = None) -> Dict[str, Any]:
    case = case_manager.get_case(case_id)
    if case is None:
        raise ValueError("case not found")
    case["status"] = CaseStatus.ESCALATED.value
    case["timeline"].append(_timeline_event("CASE_ESCALATED", f"by={escalated_by}"))
    if notes:
        case["analyst_notes"].append(f"{escalated_by}: {notes}")
    case["updated_at"] = datetime.utcnow().isoformat()
    case_manager.save_case(case)
    case_manager.log_audit(case_id, escalated_by, "ESCALATED", notes or "")
    return case

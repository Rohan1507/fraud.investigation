"""
GraphRAG-style retrieval layer.

Flow implemented here (see docs/ARCHITECTURE.md for the full diagram):
  investigation context -> entity/keyword extraction -> graph neighborhood
  (via graph_engine) -> policy retrieval -> pattern retrieval ->
  similar-case retrieval (via graph_engine) -> ranked, deduplicated context
  handed to the agent for LLM-assisted explanation.

Retrieval here uses simple TF-IDF cosine similarity (scikit-learn) over the
policy/pattern documents. This is intentionally transparent and inspectable
rather than a black box, and is swappable for a real vector DB without
changing the agent's interface (retrieve_policies / retrieve_patterns).
"""
import json
from pathlib import Path
from typing import Any, Dict, List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from . import config


class DocumentRetriever:
    def __init__(self, docs: List[Dict[str, Any]], text_field: str):
        self.docs = docs
        self.text_field = text_field
        texts = [d[text_field] for d in docs]
        self.vectorizer = TfidfVectorizer(stop_words="english") if texts else None
        self.matrix = self.vectorizer.fit_transform(texts) if texts else None

    def search(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        if not self.docs or self.matrix is None:
            return []
        q_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(q_vec, self.matrix)[0]
        ranked = sorted(zip(self.docs, sims), key=lambda x: -x[1])
        return [{**doc, "relevance": round(float(score), 3)} for doc, score in ranked[:top_k] if score > 0]


def _load_json(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with open(path) as f:
        return json.load(f)


class RagIndex:
    def __init__(self):
        self.policies = _load_json(config.SAMPLE_DIR / "policies.json")
        self.patterns = _load_json(config.SAMPLE_DIR / "fraud_patterns.json")
        self.policy_retriever = DocumentRetriever(self.policies, "text")
        self.pattern_retriever = DocumentRetriever(self.patterns, "description")

    def retrieve_policies(self, query: str, top_k: int = 3):
        return self.policy_retriever.search(query, top_k)

    def retrieve_patterns(self, query: str, top_k: int = 3):
        return self.pattern_retriever.search(query, top_k)


rag_index = RagIndex()

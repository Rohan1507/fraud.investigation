"""
Policy-aware next-best-action engine.

Implements the action policy table from the spec. The LLM never picks an
action directly — it is only allowed to explain the choice the policy engine
already made deterministically. High-impact actions always carry an
approval_required_role, and the API layer refuses to execute them until
POST /cases/{id}/approve has been called by that role.
"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .models import ActionType, EvidenceStrength, Role

# Action policy table -- the single source of truth for what can happen when.
ACTION_POLICY_TABLE: List[Dict[str, Any]] = [
    {
        "action": ActionType.ALLOW_TRANSACTION,
        "risk_max": 30,
        "evidence_requirement": "any",
        "approval_required_role": None,
        "allowed_roles": [Role.ANALYST, Role.ADMIN],
        "reason": "Low risk with no suspicious connected-entity evidence.",
    },
    {
        "action": ActionType.MONITOR_ACCOUNT,
        "risk_min": 30, "risk_max": 55,
        "evidence_requirement": "any",
        "approval_required_role": None,
        "allowed_roles": [Role.ANALYST, Role.ADMIN],
        "reason": "Moderate risk; not enough to act, but the account should be watched.",
    },
    {
        "action": ActionType.REQUEST_STEP_UP_AUTHENTICATION,
        "risk_min": 55, "risk_max": 90,
        "evidence_requirement": "medium_or_high",
        "requires_unverified_ownership": True,
        "approval_required_role": None,
        "allowed_roles": [Role.ANALYST, Role.ADMIN],
        "reason": "High risk but transaction ownership/authenticity is not yet verified (POL-001).",
    },
    {
        "action": ActionType.REQUEST_MORE_EVIDENCE,
        "confidence_max": 0.75,
        "evidence_requirement": "any",
        "approval_required_role": None,
        "allowed_roles": [Role.ANALYST, Role.ADMIN],
        "reason": "Confidence is below the sufficiency threshold; more evidence is required before acting (POL-004).",
    },
    {
        "action": ActionType.BLOCK_TRANSACTION,
        "risk_min": 75,
        "evidence_requirement": "high",
        "requires_failed_auth_or_two_flags": True,
        "approval_required_role": Role.ANALYST,
        "allowed_roles": [Role.ANALYST, Role.ADMIN],
        "reason": "High risk, strong evidence, and (failed step-up auth OR >=2 confirmed-fraud-linked "
                  "connected entities) per POL-002.",
    },
    {
        "action": ActionType.FREEZE_ACCOUNT,
        "risk_min": 80,
        "evidence_requirement": "high",
        "approval_required_role": Role.ANALYST,
        "allowed_roles": [Role.ANALYST, Role.ADMIN],
        "reason": "Very high risk repeated within a short window, per POL-003.",
    },
    {
        "action": ActionType.ESCALATE_TO_ANALYST,
        "evidence_requirement": "any",
        "approval_required_role": None,
        "allowed_roles": [Role.ANALYST, Role.ADMIN],
        "reason": "Maximum evidence-gathering rounds exhausted without reaching sufficient confidence (POL-004).",
    },
]


@dataclass
class ActionDecision:
    action: ActionType
    reason: str
    approval_required_role: Optional[Role]


def decide_next_action(
    risk_score: float,
    confidence: float,
    evidence_strength: EvidenceStrength,
    ownership_verified: bool,
    step_up_failed: bool,
    n_confirmed_fraud_links: int,
    evidence_rounds_exhausted: bool,
) -> ActionDecision:
    """Pure function: same inputs always produce the same action. This is what
    makes the recommendation auditable and testable independent of any LLM."""

    # POL-005: low risk with no confirmed-fraud-linked connections is allowed outright,
    # even if the generic confidence score hasn't crossed the sufficiency threshold --
    # there is simply nothing suspicious to gather more evidence about.
    if risk_score < 30 and n_confirmed_fraud_links == 0:
        rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.ALLOW_TRANSACTION)
        return ActionDecision(rule["action"], rule["reason"], rule["approval_required_role"])

    if evidence_rounds_exhausted and confidence < 0.75:
        rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.ESCALATE_TO_ANALYST)
        return ActionDecision(rule["action"], rule["reason"], rule["approval_required_role"])

    if confidence < 0.75:
        rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.REQUEST_MORE_EVIDENCE)
        return ActionDecision(rule["action"], rule["reason"], rule["approval_required_role"])

    if risk_score >= 75 and evidence_strength == EvidenceStrength.HIGH and \
            (step_up_failed or n_confirmed_fraud_links >= 2):
        rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.BLOCK_TRANSACTION)
        return ActionDecision(rule["action"], rule["reason"], rule["approval_required_role"])

    if risk_score >= 55 and not ownership_verified and not step_up_failed:
        rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.REQUEST_STEP_UP_AUTHENTICATION)
        return ActionDecision(rule["action"], rule["reason"], rule["approval_required_role"])

    if risk_score >= 55 and step_up_failed:
        # authentication already failed but evidence isn't HIGH enough to block outright
        rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.ESCALATE_TO_ANALYST)
        return ActionDecision(rule["action"],
                               "Step-up authentication failed but evidence strength is not yet HIGH; "
                               "escalating to a human analyst rather than auto-blocking.",
                               rule["approval_required_role"])

    if risk_score >= 30:
        rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.MONITOR_ACCOUNT)
        return ActionDecision(rule["action"], rule["reason"], rule["approval_required_role"])

    rule = next(r for r in ACTION_POLICY_TABLE if r["action"] == ActionType.ALLOW_TRANSACTION)
    return ActionDecision(rule["action"], rule["reason"], rule["approval_required_role"])

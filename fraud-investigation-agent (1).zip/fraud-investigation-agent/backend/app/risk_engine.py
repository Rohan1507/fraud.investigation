"""
Deterministic risk & evidence-confidence engine.

Per the spec, the LLM must NEVER invent a fraud probability. All numeric risk
is computed here from graph evidence with fixed, configurable weights, and
every point is attributable to a specific piece of evidence. The LLM (agent.py)
only *explains* this score in natural language — it cannot change it.
"""
from dataclasses import dataclass
from typing import Any, Dict, List

from .models import EvidenceStrength, RiskBreakdown

# Configurable weights (also exposed on the Admin page)
WEIGHTS = {
    "bank_risk_score": 0.35,          # scaled contribution of the upstream bank score
    "shared_device_flagged": 22,      # a customer sharing this device has confirmed fraud history
    "shared_device_unflagged": 8,     # device is shared but no confirmed history (yet)
    "shared_ip_flagged": 18,
    "shared_ip_unflagged": 6,
    "high_velocity": 10,              # customer has unusually many transactions
    "large_amount": 10,               # transaction amount is an outlier
    "similar_confirmed_case": 15,     # a similar historical case was Confirmed Fraud
    "similar_cleared_case": -5,       # a similar historical case was Cleared (reduces risk)
}

VELOCITY_THRESHOLD = 12
LARGE_AMOUNT_THRESHOLD = 8000


@dataclass
class RiskResult:
    risk_score: float
    confidence: float
    evidence_strength: EvidenceStrength
    investigation_status: str
    breakdown: List[RiskBreakdown]


def compute_risk(
    transaction: Dict[str, Any],
    connected: Dict[str, Any],
    velocity: int,
    similar_cases: List[Dict[str, Any]],
) -> RiskResult:
    breakdown: List[RiskBreakdown] = []
    score = 0.0

    bank_score = float(transaction.get("bank_risk_score", 0))
    contrib = round(bank_score * WEIGHTS["bank_risk_score"], 1)
    score += contrib
    breakdown.append(RiskBreakdown(
        label="bank_risk_score", points=contrib,
        reason=f"Upstream bank fraud-model score is {bank_score}/100"))

    flagged_ids = {f["customer_id"] for f in connected.get("flagged_connected_customers", [])}

    if connected.get("customers_sharing_device"):
        flagged = [c for c in connected["customers_sharing_device"] if c in flagged_ids]
        if flagged:
            score += WEIGHTS["shared_device_flagged"]
            breakdown.append(RiskBreakdown(
                label="shared_device_flagged", points=WEIGHTS["shared_device_flagged"],
                reason=f"Device {connected.get('device_id')} is shared with {len(flagged)} "
                       f"customer(s) with confirmed fraud history: {flagged}"))
        else:
            score += WEIGHTS["shared_device_unflagged"]
            breakdown.append(RiskBreakdown(
                label="shared_device_unflagged", points=WEIGHTS["shared_device_unflagged"],
                reason=f"Device {connected.get('device_id')} is shared with "
                       f"{len(connected['customers_sharing_device'])} other customer(s), none flagged yet"))

    if connected.get("customers_sharing_ip"):
        flagged = [c for c in connected["customers_sharing_ip"] if c in flagged_ids]
        if flagged:
            score += WEIGHTS["shared_ip_flagged"]
            breakdown.append(RiskBreakdown(
                label="shared_ip_flagged", points=WEIGHTS["shared_ip_flagged"],
                reason=f"IP {connected.get('ip_address')} is shared with {len(flagged)} "
                       f"customer(s) with confirmed fraud history: {flagged}"))
        else:
            score += WEIGHTS["shared_ip_unflagged"]
            breakdown.append(RiskBreakdown(
                label="shared_ip_unflagged", points=WEIGHTS["shared_ip_unflagged"],
                reason=f"IP {connected.get('ip_address')} is shared with "
                       f"{len(connected['customers_sharing_ip'])} other customer(s), none flagged yet"))

    if velocity >= VELOCITY_THRESHOLD:
        score += WEIGHTS["high_velocity"]
        breakdown.append(RiskBreakdown(
            label="high_velocity", points=WEIGHTS["high_velocity"],
            reason=f"Customer has {velocity} total transactions, above the velocity threshold "
                   f"of {VELOCITY_THRESHOLD}"))

    amount = float(transaction.get("amount", 0))
    if amount >= LARGE_AMOUNT_THRESHOLD:
        score += WEIGHTS["large_amount"]
        breakdown.append(RiskBreakdown(
            label="large_amount", points=WEIGHTS["large_amount"],
            reason=f"Transaction amount {amount} exceeds the large-amount threshold of {LARGE_AMOUNT_THRESHOLD}"))

    n_confirmed = sum(1 for c in similar_cases if c.get("outcome") == "Confirmed Fraud")
    n_cleared = sum(1 for c in similar_cases if c.get("outcome") == "Cleared")
    if n_confirmed:
        pts = WEIGHTS["similar_confirmed_case"] * min(n_confirmed, 2)
        score += pts
        breakdown.append(RiskBreakdown(
            label="similar_confirmed_case", points=pts,
            reason=f"{n_confirmed} similar historical case(s) were Confirmed Fraud"))
    if n_cleared:
        pts = WEIGHTS["similar_cleared_case"] * min(n_cleared, 2)
        score += pts
        breakdown.append(RiskBreakdown(
            label="similar_cleared_case", points=pts,
            reason=f"{n_cleared} similar historical case(s) were Cleared (reduces risk)"))

    risk_score = max(0.0, min(round(score, 1), 100.0))

    # Confidence grows with the amount and quality of evidence gathered
    evidence_count = len(breakdown)
    has_flagged = bool(flagged_ids)
    has_similar = bool(similar_cases)
    confidence = min(0.4 + 0.08 * evidence_count + (0.15 if has_flagged else 0) + (0.1 if has_similar else 0), 0.98)
    confidence = round(confidence, 2)

    if risk_score >= 70 and has_flagged:
        strength = EvidenceStrength.HIGH
    elif risk_score >= 40 or has_similar:
        strength = EvidenceStrength.MEDIUM
    else:
        strength = EvidenceStrength.LOW

    if confidence < 0.6:
        status = "Insufficient Evidence"
    elif confidence < 0.75:
        status = "Needs More Evidence"
    else:
        status = "Sufficient Evidence"

    return RiskResult(risk_score, confidence, strength, status, breakdown)

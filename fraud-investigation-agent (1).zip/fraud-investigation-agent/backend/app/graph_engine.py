"""
Graph engine abstraction.

This module exposes the SAME query interface regardless of backend:
  - DEMO_MODE / TIGERGRAPH_AVAILABLE=false -> in-memory networkx graph built
    from data/sample (or data/raw once you point it at the real dataset).
  - TIGERGRAPH_AVAILABLE=true -> calls installed GSQL queries in
    tigergraph/gsql/*.gsql via TigerGraph's REST++ endpoint using pyTigerGraph.

Every "investigation tool" the agent calls (get_connected_entities,
find_shared_device_customers, etc.) is implemented once here and reused by
both backends' callers, so swapping backends never changes agent behaviour.

IMPORTANT: nothing here invents relationships. Every edge added to the graph
comes directly from a row in the source data.
"""
from __future__ import annotations
import csv
import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

import networkx as nx

from . import config


class GraphEngine:
    def __init__(self):
        self.g = nx.MultiDiGraph()
        self.loaded = False
        self.stats: Dict[str, Any] = {}
        self.ingestion_errors: List[str] = []

    # ------------------------------------------------------------ ingest ---
    def load_from_csv(self, sample_dir: Optional[Path] = None):
        """Ingestion pipeline: read README/columns, validate, build graph, log stats."""
        sample_dir = sample_dir or config.SAMPLE_DIR
        errors = []

        tx_path = sample_dir / "transactions.csv"
        cust_path = sample_dir / "customers.csv"
        closed_path = sample_dir / "closed_cases.csv"

        if not tx_path.exists():
            raise FileNotFoundError(
                f"transactions file not found at {tx_path}. Run scripts/generate_sample_data.py "
                f"or point config.SAMPLE_DIR at your real dataset."
            )

        required_tx_cols = {"transaction_id", "customer_id", "device_id", "ip_address",
                             "merchant_id", "amount", "timestamp", "bank_risk_score"}

        n_tx = n_cust = n_device = n_ip = n_merchant = 0
        customer_meta = {}

        if cust_path.exists():
            with open(cust_path) as f:
                for row in csv.DictReader(f):
                    customer_meta[row["customer_id"]] = row
                    if not self.g.has_node(row["customer_id"]):
                        self.g.add_node(row["customer_id"], type="Customer", **row)
                        n_cust += 1

        with open(tx_path) as f:
            reader = csv.DictReader(f)
            header = set(reader.fieldnames or [])
            missing = required_tx_cols - header
            if missing:
                errors.append(f"transactions.csv missing expected columns: {missing}")
            for row in reader:
                try:
                    tx_id = row["transaction_id"]
                    cust_id = row["customer_id"]
                    device_id = row.get("device_id") or None
                    ip = row.get("ip_address") or None
                    merchant = row.get("merchant_id") or None
                    amount = float(row.get("amount") or 0)
                    risk = float(row.get("bank_risk_score") or 0)

                    self.g.add_node(tx_id, type="Transaction", amount=amount,
                                     bank_risk_score=risk, timestamp=row.get("timestamp"),
                                     merchant_id=merchant)
                    n_tx += 1

                    if not self.g.has_node(cust_id):
                        self.g.add_node(cust_id, type="Customer")
                        n_cust += 1
                    self.g.add_edge(cust_id, tx_id, type="PERFORMED")

                    if device_id:
                        if not self.g.has_node(device_id):
                            self.g.add_node(device_id, type="Device")
                            n_device += 1
                        self.g.add_edge(tx_id, device_id, type="USED_DEVICE")

                    if ip:
                        if not self.g.has_node(ip):
                            self.g.add_node(ip, type="IPAddress")
                            n_ip += 1
                        self.g.add_edge(tx_id, ip, type="FROM_IP")

                    if merchant:
                        if not self.g.has_node(merchant):
                            self.g.add_node(merchant, type="Merchant")
                            n_merchant += 1
                        self.g.add_edge(tx_id, merchant, type="TO_MERCHANT")
                except Exception as e:  # noqa: BLE001
                    errors.append(f"row error on {row.get('transaction_id')}: {e}")

        n_closed = 0
        if closed_path.exists():
            with open(closed_path) as f:
                for row in csv.DictReader(f):
                    case_id = row["case_id"]
                    self.g.add_node(case_id, type="InvestigationCase", **row)
                    if self.g.has_node(row.get("transaction_id")):
                        self.g.add_edge(case_id, row["transaction_id"], type="INVESTIGATES")
                    if self.g.has_node(row.get("customer_id")):
                        self.g.add_edge(case_id, row["customer_id"], type="INVOLVES")
                    n_closed += 1

        self.loaded = True
        self.ingestion_errors = errors
        self.stats = {
            "transactions": n_tx, "customers": n_cust, "devices": n_device,
            "ip_addresses": n_ip, "merchants": n_merchant, "closed_cases": n_closed,
            "total_nodes": self.g.number_of_nodes(), "total_edges": self.g.number_of_edges(),
            "errors": len(errors),
        }
        return self.stats

    # ------------------------------------------------------- query tools ---
    # Each of these corresponds 1:1 to a GSQL query in tigergraph/gsql/*.gsql
    # (see that folder for the real-deployment equivalents).

    def get_transaction(self, tx_id: str) -> Optional[Dict[str, Any]]:
        if not self.g.has_node(tx_id):
            return None
        data = dict(self.g.nodes[tx_id])
        customer = next((u for u, v, d in self.g.in_edges(tx_id, data=True)
                          if d.get("type") == "PERFORMED"), None)
        data["transaction_id"] = tx_id
        data["customer_id"] = customer
        return data

    def get_customer_profile(self, customer_id: str) -> Optional[Dict[str, Any]]:
        if not self.g.has_node(customer_id):
            return None
        data = dict(self.g.nodes[customer_id])
        data["customer_id"] = customer_id
        tx_ids = [v for u, v, d in self.g.out_edges(customer_id, data=True) if d.get("type") == "PERFORMED"]
        data["transaction_count"] = len(tx_ids)
        return data

    def get_neighbors(self, node_id: str, edge_type: Optional[str] = None) -> List[str]:
        out = [v for u, v, d in self.g.out_edges(node_id, data=True)
               if edge_type is None or d.get("type") == edge_type]
        inn = [u for u, v, d in self.g.in_edges(node_id, data=True)
               if edge_type is None or d.get("type") == edge_type]
        return list(set(out + inn))

    def get_transaction_device_and_ip(self, tx_id: str) -> Dict[str, Optional[str]]:
        device = next((v for u, v, d in self.g.out_edges(tx_id, data=True)
                        if d.get("type") == "USED_DEVICE"), None)
        ip = next((v for u, v, d in self.g.out_edges(tx_id, data=True)
                   if d.get("type") == "FROM_IP"), None)
        return {"device_id": device, "ip_address": ip}

    def find_customers_sharing_entity(self, entity_id: str) -> List[str]:
        """Customers who share a Device or IPAddress via their transactions (2-hop traversal)."""
        if not self.g.has_node(entity_id):
            return []
        txs = [u for u, v, d in self.g.in_edges(entity_id, data=True)
               if d.get("type") in ("USED_DEVICE", "FROM_IP")]
        customers = set()
        for tx in txs:
            for u, v, d in self.g.in_edges(tx, data=True):
                if d.get("type") == "PERFORMED":
                    customers.add(u)
        return sorted(customers)

    def get_connected_entities(self, tx_id: str) -> Dict[str, Any]:
        """Full connected-entity picture for a transaction: device, ip, merchant,
        and every OTHER customer sharing that device/ip, plus whether those
        customers have confirmed-fraud history."""
        info = self.get_transaction_device_and_ip(tx_id)
        device, ip = info["device_id"], info["ip_address"]
        this_customer = next((u for u, v, d in self.g.in_edges(tx_id, data=True)
                               if d.get("type") == "PERFORMED"), None)

        device_customers = self.find_customers_sharing_entity(device) if device else []
        ip_customers = self.find_customers_sharing_entity(ip) if ip else []
        other_device_customers = [c for c in device_customers if c != this_customer]
        other_ip_customers = [c for c in ip_customers if c != this_customer]

        flagged = []
        for c in set(other_device_customers + other_ip_customers):
            history = self.get_customer_fraud_history(c)
            if history:
                flagged.append({"customer_id": c, "history": history})

        return {
            "device_id": device,
            "ip_address": ip,
            "customers_sharing_device": other_device_customers,
            "customers_sharing_ip": other_ip_customers,
            "flagged_connected_customers": flagged,
        }

    def get_customer_fraud_history(self, customer_id: str) -> List[Dict[str, Any]]:
        cases = [u for u, v, d in self.g.in_edges(customer_id, data=True) if d.get("type") == "INVOLVES"]
        out = []
        for case_id in cases:
            node = self.g.nodes[case_id]
            if node.get("outcome") == "Confirmed Fraud":
                out.append({"case_id": case_id, "pattern": node.get("pattern"), "outcome": node.get("outcome")})
        return out

    def get_transaction_velocity(self, customer_id: str, window_txs: int = 5) -> int:
        """Rough velocity signal: count of that customer's transactions in the graph
        (a real deployment would window this by timestamp; kept simple + inspectable here)."""
        tx_ids = [v for u, v, d in self.g.out_edges(customer_id, data=True) if d.get("type") == "PERFORMED"]
        return len(tx_ids)

    def find_repeated_merchant_relationships(self, customer_id: str) -> Dict[str, int]:
        tx_ids = [v for u, v, d in self.g.out_edges(customer_id, data=True) if d.get("type") == "PERFORMED"]
        counts: Dict[str, int] = defaultdict(int)
        for tx in tx_ids:
            merchant = next((v for u, v, d in self.g.out_edges(tx, data=True)
                              if d.get("type") == "TO_MERCHANT"), None)
            if merchant:
                counts[merchant] += 1
        return dict(counts)

    def find_similar_historical_cases(self, tx_id: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Very simple similarity: shared device/ip/merchant with a closed case's
        transaction, or the same customer. Returns highest-overlap cases first.
        (A production system would embed case narratives for vector similarity;
        this keeps the signal fully inspectable for the prototype.)"""
        info = self.get_transaction_device_and_ip(tx_id)
        target_device, target_ip = info["device_id"], info["ip_address"]
        tx_node = self.g.nodes.get(tx_id, {})
        target_merchant = tx_node.get("merchant_id")

        scored = []
        for node_id, data in self.g.nodes(data=True):
            if data.get("type") != "InvestigationCase":
                continue
            case_tx = next((v for u, v, d in self.g.out_edges(node_id, data=True)
                             if d.get("type") == "INVESTIGATES"), None)
            if not case_tx or not self.g.has_node(case_tx):
                continue
            other_info = self.get_transaction_device_and_ip(case_tx)
            other_node = self.g.nodes.get(case_tx, {})
            score = 0.0
            if target_device and other_info["device_id"] == target_device:
                score += 0.5
            if target_ip and other_info["ip_address"] == target_ip:
                score += 0.3
            if target_merchant and other_node.get("merchant_id") == target_merchant:
                score += 0.15
            if score > 0:
                scored.append({
                    "case_id": node_id,
                    "similarity": round(min(score + 0.05, 0.99), 2),
                    "pattern": data.get("pattern", "unknown"),
                    "outcome": data.get("outcome", "unknown"),
                })
        scored.sort(key=lambda x: -x["similarity"])
        return scored[:top_k]


# Singleton used by the rest of the app
graph_engine = GraphEngine()

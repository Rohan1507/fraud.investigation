"""
Mock/simulated evidence-gathering and action-execution APIs.

The spec explicitly allows these to be simulated. Each function returns a
structured record: request, timestamp, reason, requested_by, response,
evidence_obtained, effect_on_risk -- and is clearly namespaced under
mock_* so it is never confused with a real integration. Swap these for real
SMS/push/CRM/bank calls without touching agent.py's control flow.
"""
import random
from datetime import datetime
from typing import Any, Dict


def mock_request_step_up_authentication(customer_id: str, transaction_id: str) -> Dict[str, Any]:
    # Deterministic-ish demo behaviour: higher chance of failure for repeat-flagged demo customers
    success = random.random() > 0.45
    return {
        "request": "step_up_authentication",
        "timestamp": datetime.utcnow().isoformat(),
        "reason": "Risk threshold exceeded; ownership not yet verified",
        "requested_by": "agent",
        "customer_id": customer_id,
        "transaction_id": transaction_id,
        "response": "AUTHENTICATED" if success else "FAILED",
        "evidence_obtained": "Customer confirmed transaction ownership" if success
        else "Customer could not complete authentication challenge",
        "effect_on_risk": "decrease" if success else "increase",
    }


def mock_request_customer_validation(transaction_id: str) -> Dict[str, Any]:
    success = random.random() > 0.5
    return {
        "request": "customer_validation",
        "timestamp": datetime.utcnow().isoformat(),
        "reason": "Confirming transaction was recognized by the customer",
        "requested_by": "agent",
        "transaction_id": transaction_id,
        "response": "CONFIRMED" if success else "DENIED",
        "evidence_obtained": "Customer recognized the transaction" if success
        else "Customer did not recognize the transaction",
        "effect_on_risk": "decrease" if success else "increase",
    }


def mock_request_additional_information(case_id: str) -> Dict[str, Any]:
    return {
        "request": "analyst_information",
        "timestamp": datetime.utcnow().isoformat(),
        "reason": "Automated evidence insufficient; requesting analyst input",
        "requested_by": "agent",
        "case_id": case_id,
        "response": "PENDING",
        "evidence_obtained": None,
        "effect_on_risk": "none",
    }


def mock_execute_action(action: str, case_id: str, transaction_id: str) -> Dict[str, Any]:
    """Simulated execution of a high-impact action (block/freeze/warn/etc.)."""
    return {
        "action": action,
        "timestamp": datetime.utcnow().isoformat(),
        "case_id": case_id,
        "transaction_id": transaction_id,
        "status": "SIMULATED_EXECUTED",
        "note": "This is a mock execution for the prototype. Wire this function to a real "
                "core-banking / CRM API for production use.",
    }

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from app.graph_engine import graph_engine
from app import agent, config, case_manager


@pytest.fixture(autouse=True, scope="module")
def _load_graph():
    graph_engine.load_from_csv()
    yield


def _any_transaction_id():
    import csv
    with open(config.SAMPLE_DIR / "transactions.csv") as f:
        return next(csv.DictReader(f))["transaction_id"]


def test_investigation_creates_case_with_full_timeline():
    tx_id = _any_transaction_id()
    case = agent.run_investigation(tx_id, "unit_test")
    assert case["case_id"].startswith("F-")
    assert case["transaction_id"] == tx_id
    events = [e["event"] for e in case["timeline"]]
    assert "TRIGGER_RECEIVED" in events
    assert "CASE_CREATED" in events
    assert "CASE_MEMORY_UPDATED" in events


def test_investigation_never_exceeds_max_steps():
    tx_id = _any_transaction_id()
    case = agent.run_investigation(tx_id, "unit_test_loop")
    # +buffer for post-loop action/approval/resolution steps that are allowed
    # to run once the loop itself has terminated
    assert case["step_count"] <= config.MAX_INVESTIGATION_STEPS + 6


def test_high_impact_action_requires_approval_before_execution():
    # find a transaction likely to trigger BLOCK by scanning a few
    import csv
    with open(config.SAMPLE_DIR / "transactions.csv") as f:
        rows = list(csv.DictReader(f))
    blocked_case = None
    for r in sorted(rows, key=lambda r: -float(r["bank_risk_score"]))[:10]:
        c = agent.run_investigation(r["transaction_id"], "unit_test_block_search")
        if c["recommended_action"]["action"] == "BLOCK_TRANSACTION":
            blocked_case = c
            break
    if blocked_case:
        assert blocked_case["recommended_action"]["executed"] is False
        assert blocked_case["approval_status"] == "PENDING"


def test_approval_executes_the_action():
    import csv
    with open(config.SAMPLE_DIR / "transactions.csv") as f:
        rows = list(csv.DictReader(f))
    for r in sorted(rows, key=lambda r: -float(r["bank_risk_score"]))[:10]:
        c = agent.run_investigation(r["transaction_id"], "unit_test_approve")
        if c["recommended_action"]["approval_required_role"]:
            approved = agent.approve_action(c["case_id"], "analyst_1", approve=True)
            assert approved["recommended_action"]["executed"] is True
            assert approved["status"] == "RESOLVED"
            return
    pytest.skip("no approval-required case found in sample of 10 transactions")


def test_rejection_closes_case_without_executing():
    import csv
    with open(config.SAMPLE_DIR / "transactions.csv") as f:
        rows = list(csv.DictReader(f))
    for r in sorted(rows, key=lambda r: -float(r["bank_risk_score"]))[:10]:
        c = agent.run_investigation(r["transaction_id"], "unit_test_reject")
        if c["recommended_action"]["approval_required_role"]:
            rejected = agent.approve_action(c["case_id"], "analyst_1", approve=False)
            assert rejected["recommended_action"]["executed"] is False
            assert rejected["status"] == "CLOSED"
            return
    pytest.skip("no approval-required case found in sample of 10 transactions")


def test_unknown_transaction_raises():
    with pytest.raises(ValueError):
        agent.run_investigation("TX_NOT_REAL", "unit_test")

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.graph_engine import GraphEngine
from app import config


def _engine():
    e = GraphEngine()
    e.load_from_csv(config.SAMPLE_DIR)
    return e


def test_graph_loads_with_no_errors():
    e = _engine()
    assert e.loaded
    assert e.stats["transactions"] > 0
    assert e.stats["errors"] == 0


def test_get_transaction_returns_expected_fields():
    e = _engine()
    tx_id = "TX10000"
    tx = e.get_transaction(tx_id)
    assert tx is not None
    assert tx["transaction_id"] == tx_id
    assert "customer_id" in tx


def test_get_transaction_missing_returns_none():
    e = _engine()
    assert e.get_transaction("TX_DOES_NOT_EXIST") is None


def test_shared_device_detection_is_symmetric():
    e = _engine()
    tx = e.get_transaction("TX10000")
    info = e.get_transaction_device_and_ip("TX10000")
    if info["device_id"]:
        sharers = e.find_customers_sharing_entity(info["device_id"])
        assert tx["customer_id"] in sharers


def test_connected_entities_never_invents_customers():
    """Every customer returned as 'sharing' must actually have a PERFORMED edge
    to a transaction that used the shared device/ip -- i.e. no invented evidence."""
    e = _engine()
    connected = e.get_connected_entities("TX10000")
    for c in connected["customers_sharing_device"]:
        assert e.g.has_node(c) and e.g.nodes[c]["type"] == "Customer"

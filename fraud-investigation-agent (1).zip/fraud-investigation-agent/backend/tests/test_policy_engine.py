import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.policy_engine import decide_next_action
from app.models import ActionType, EvidenceStrength


def test_low_risk_allows_transaction():
    d = decide_next_action(risk_score=10, confidence=0.9, evidence_strength=EvidenceStrength.LOW,
                            ownership_verified=False, step_up_failed=False,
                            n_confirmed_fraud_links=0, evidence_rounds_exhausted=False)
    assert d.action == ActionType.ALLOW_TRANSACTION


def test_low_confidence_requests_more_evidence():
    d = decide_next_action(risk_score=60, confidence=0.5, evidence_strength=EvidenceStrength.MEDIUM,
                            ownership_verified=False, step_up_failed=False,
                            n_confirmed_fraud_links=0, evidence_rounds_exhausted=False)
    assert d.action == ActionType.REQUEST_MORE_EVIDENCE


def test_high_risk_unverified_requests_step_up():
    d = decide_next_action(risk_score=80, confidence=0.9, evidence_strength=EvidenceStrength.HIGH,
                            ownership_verified=False, step_up_failed=False,
                            n_confirmed_fraud_links=0, evidence_rounds_exhausted=False)
    assert d.action == ActionType.REQUEST_STEP_UP_AUTHENTICATION


def test_high_risk_high_evidence_failed_auth_blocks_with_approval():
    d = decide_next_action(risk_score=85, confidence=0.9, evidence_strength=EvidenceStrength.HIGH,
                            ownership_verified=False, step_up_failed=True,
                            n_confirmed_fraud_links=1, evidence_rounds_exhausted=False)
    assert d.action == ActionType.BLOCK_TRANSACTION
    assert d.approval_required_role is not None


def test_exhausted_rounds_low_confidence_escalates():
    d = decide_next_action(risk_score=60, confidence=0.5, evidence_strength=EvidenceStrength.MEDIUM,
                            ownership_verified=False, step_up_failed=False,
                            n_confirmed_fraud_links=0, evidence_rounds_exhausted=True)
    assert d.action == ActionType.ESCALATE_TO_ANALYST


def test_moderate_risk_monitors():
    d = decide_next_action(risk_score=40, confidence=0.9, evidence_strength=EvidenceStrength.MEDIUM,
                            ownership_verified=True, step_up_failed=False,
                            n_confirmed_fraud_links=0, evidence_rounds_exhausted=False)
    assert d.action == ActionType.MONITOR_ACCOUNT

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.risk_engine import compute_risk
from app.models import EvidenceStrength


def test_clean_transaction_low_risk():
    tx = {"bank_risk_score": 5, "amount": 100}
    connected = {"device_id": "D1", "ip_address": "1.1.1.1",
                 "customers_sharing_device": [], "customers_sharing_ip": [],
                 "flagged_connected_customers": []}
    result = compute_risk(tx, connected, velocity=2, similar_cases=[])
    assert result.risk_score < 30
    assert result.evidence_strength == EvidenceStrength.LOW


def test_flagged_shared_device_raises_risk():
    tx = {"bank_risk_score": 40, "amount": 500}
    connected = {"device_id": "D1", "ip_address": "1.1.1.1",
                 "customers_sharing_device": ["C2"], "customers_sharing_ip": [],
                 "flagged_connected_customers": [{"customer_id": "C2", "history": [{"case_id": "F-1"}]}]}
    result = compute_risk(tx, connected, velocity=2, similar_cases=[])
    assert result.risk_score > 30
    assert any(b.label == "shared_device_flagged" for b in result.breakdown)


def test_similar_confirmed_case_increases_risk_and_confidence():
    tx = {"bank_risk_score": 40, "amount": 500}
    connected = {"device_id": "D1", "ip_address": "1.1.1.1",
                 "customers_sharing_device": [], "customers_sharing_ip": [],
                 "flagged_connected_customers": []}
    no_similar = compute_risk(tx, connected, velocity=2, similar_cases=[])
    with_similar = compute_risk(tx, connected, velocity=2,
                                 similar_cases=[{"case_id": "F-1", "outcome": "Confirmed Fraud",
                                                  "pattern": "shared_device", "similarity": 0.9}])
    assert with_similar.risk_score > no_similar.risk_score
    assert with_similar.confidence >= no_similar.confidence


def test_high_amount_contributes_points():
    tx_small = {"bank_risk_score": 20, "amount": 100}
    tx_large = {"bank_risk_score": 20, "amount": 20000}
    connected = {"device_id": "D1", "ip_address": "1.1.1.1",
                 "customers_sharing_device": [], "customers_sharing_ip": [],
                 "flagged_connected_customers": []}
    small = compute_risk(tx_small, connected, velocity=1, similar_cases=[])
    large = compute_risk(tx_large, connected, velocity=1, similar_cases=[])
    assert large.risk_score > small.risk_score


def test_risk_score_bounded_0_100():
    tx = {"bank_risk_score": 99, "amount": 999999}
    connected = {"device_id": "D1", "ip_address": "1.1.1.1",
                 "customers_sharing_device": ["C2", "C3"], "customers_sharing_ip": ["C4"],
                 "flagged_connected_customers": [
                     {"customer_id": "C2", "history": []}, {"customer_id": "C4", "history": []}]}
    similar = [{"case_id": f"F-{i}", "outcome": "Confirmed Fraud", "pattern": "x", "similarity": 0.9}
               for i in range(5)]
    result = compute_risk(tx, connected, velocity=50, similar_cases=similar)
    assert 0 <= result.risk_score <= 100
